package vttp2023.batch4.paf.assessment.models;

// IMPORTANT: DO NOT MODIFY THIS CLASS
// If this class is changed, any assessment task relying on this class will
// not be marked
public record User(String email, String name) { }
