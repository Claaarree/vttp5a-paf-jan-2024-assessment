package vttp2023.batch4.paf.assessment.services;

import org.springframework.stereotype.Service;

@Service
public class ForexService {

	// TODO: Task 5 
	public float convert(String from, String to, float amount) {

		return -1000f;
	}
}
