package vttp2023.batch4.paf.assessment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssessmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
